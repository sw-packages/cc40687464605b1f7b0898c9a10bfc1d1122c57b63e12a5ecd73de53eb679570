#include <pthread.h>

int pthread_getconcurrency()
{
	return 0;
}
