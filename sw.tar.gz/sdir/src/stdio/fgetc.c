#include <stdio.h>
#include "getc.h"

int fgetc(FILE *f)
{
	return do_getc(f);
}
