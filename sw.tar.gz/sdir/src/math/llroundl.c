#include <math.h>

long long llroundl(long double x)
{
	return roundl(x);
}
