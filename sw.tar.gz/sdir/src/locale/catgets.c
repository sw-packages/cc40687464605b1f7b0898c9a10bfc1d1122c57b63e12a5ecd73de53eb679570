#include <nl_types.h>

char *catgets (nl_catd catd, int set_id, int msg_id, const char *s)
{
	return (char *)s;
}
